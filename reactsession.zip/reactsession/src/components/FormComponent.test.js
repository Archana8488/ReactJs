import React from 'react';
//import ReactDom  from 'react-dom';
import { render, fireEvent } from '@testing-library/react';
import FormComponent from './FormComponent';

test("FormComponent should render without crash",()=>{
    const element = document.createElement["div"];
    render(<FormComponent/>,element);
})

test("Email shuld be as equal to expected",()=>{
    const {getByTestId} =render(<FormComponent/>);
    const EmailInput =getByTestId("emailInput");
    fireEvent.change(EmailInput,{target:{value:"test@gmail.com"}});

    expect(EmailInput.value).toEqual("test@gmail.com");
})