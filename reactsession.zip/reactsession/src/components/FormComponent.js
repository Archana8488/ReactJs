import React,{useState} from 'react';
import {Row,Container} from 'react-bootstrap';

const FormComponent= () =>{
    const [state,setState]=useState({
        email:"",
        username:""
    })
    const handelChange=(e)=>{
        let name=e.target.name;
        let value=e.target.value;
        setState({
            ...state,
            [name]:value
        })
    }
    return (
        <Row>
            <Container>
                     <form>
                        <div className="form-group">
                        <label htmlFor="exampleInputEmail1">Email address</label>
                         <input data-testid="emailInput" onChange={(e)=>handelChange(e)} type={state.email} className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"/>
                         <small id="emailHelp" className="form-text text-muted">Well never share your email with anyone else</small>
                         </div>
                         <div classame="form-group">
                        <label htmlFor="exampleInputPassword1">User Name</label>
                         <input  data-testid="userInput" onChange={(e)=>handelChange(e)} type="text" value={state.username} className="form-control" id="exampleInputPassword1" placeholder="username"/>
                        </div>
                        <div className="form-group form-check">
                        <input type="checkbox" className="form-check-input" id="exampleCheck1"/>
                         <label className="form-check-label" htmlFor="exampleCheck1">Check me out</label>
                         </div>
                         <button type="submit" className="btn btn-primary">Submit</button>
                     </form>
            </Container>
        </Row>
    );
}

export default FormComponent;

