import React from 'react'
import { Button, Table, Card, CardBody } from 'reactstrap';

const UserTable = props => (
    <Card>
        <CardBody>
            <Table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Address</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {props.users.length > 0 ? (
                        props.users.map(user => (
                            <tr key={user.id}>
                                <td>{user.name}</td>
                                <td>{user.username}</td>
                                <td>{user.address}</td>
                                <td>
                                    <Button outline color="primary" size="sm-6" onClick={() => {
                                        props.editRow(user)
                                    }}>Edit</Button>
                                    <Button outline color="danger" size="sm-6" onClick={() => props.deleteUser(user.id)}>Delete</Button>
                                </td>
                            </tr>
                        ))
                    ) : (
                            <tr>
                                <td colSpan={3}>No users</td>
                            </tr>
                        )}
                </tbody>
            </Table>
        </CardBody>
    </Card>
)

export default UserTable