import React, { useState } from 'react'
import { FormGroup, Input, Label, Button, Card, CardBody } from 'reactstrap';

const AddUserForm = props => {
    const initialFormState = { id: null, name: '', username: '',address: '' }
    const [user, setUser] = useState(initialFormState)

    const handleInputChange = event => {
        const { name, value } = event.target
        const { username, setvalue } = event.target
        const { address, setAddress } = event.target

        setUser({ ...user, [name]: value, [username]: setvalue ,[address]:setAddress})
    }

    return (
        <Card>
            <CardBody>
                <form
                    onSubmit={event => {
                        event.preventDefault()
                        if (!user.name || !user.username) return

                        props.addUser(user)
                        setUser(initialFormState)
                    }}
                >
                    <FormGroup>
                        <Label for="name">Name</Label>
                        <Input type="text" name="name" placeholder="name" value={user.name} onChange={handleInputChange} />
                    </FormGroup>
                    <FormGroup>
                        <Label for="username">User Name</Label>
                        <Input type="text" name="username" placeholder="username" value={user.username} onChange={handleInputChange} />
                    </FormGroup>
                    <FormGroup>
                        <Label for="address">Address</Label>
                        <Input type="text" name="address" placeholder="address" value={user.address} onChange={handleInputChange} />
                    </FormGroup>
                    <Button color="primary">Add new user</Button>
                </form>
            </CardBody>
        </Card>
    )
}

export default AddUserForm
