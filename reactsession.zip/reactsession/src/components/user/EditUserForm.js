import React, { useState, useEffect } from 'react'
import { FormGroup, Input, Label, Button, Card, CardBody } from 'reactstrap';

const EditUserForm = props => {
    const [user, setUser] = useState(props.currentUser)
    console.log(props.id);
    useEffect(
        () => {
            setUser(props.currentUser)
        },
        [props]
    )

    const handleInputChange = event => {
        const { name, value } = event.target
        const { username, setvalue } = event.target
        const { address, setAddress } = event.target

        setUser({ ...user, [name]: value, [username]: setvalue ,[address]:setAddress})
    }

    return (
        <Card>
            <CardBody>


                <form
                    onSubmit={event => {
                        event.preventDefault()

                        props.updateUser(user.id, user)
                    }}
                >
                    <FormGroup>
                        <Label for="name">Name</Label>
                        <Input type="text" name="name" placeholder="name" value={user.name} onChange={handleInputChange} />
                    </FormGroup>
                    <FormGroup>
                        <Label for="username">User Name</Label>
                        <Input type="text" name="username" placeholder="username" value={user.username} onChange={handleInputChange} />
                    </FormGroup>
                    <FormGroup>
                        <Label for="address">Address</Label>
                        <Input type="text" name="address" placeholder="address" value={user.address} onChange={handleInputChange} />
                    </FormGroup>
                    <Button color="primary">Update user</Button>
                    <Button onClick={() => props.setEditing(false)} outline color="primary">
                        Cancel
            </Button>
                </form>
            </CardBody>
        </Card>
    )
}

export default EditUserForm
