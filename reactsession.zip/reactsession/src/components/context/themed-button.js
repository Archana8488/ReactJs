import ThemeContext from './UserContext';
import React from 'react';

const ThemedButton =()=>{
    return (
        <ThemeContext.Consumer>
        {({theme, toggleTheme}) => (
          <button
            onClick={toggleTheme}
            style={{backgroundColor: theme.background}}>
            Toggle Theme
          </button>
        )}
      </ThemeContext.Consumer>
      );
}

export default ThemedButton;