import React,{useContext} from 'react';
import {UserContext} from '../components/context/UserContext';

const Home =(props)=>{

        console.log(props);
    setTimeout(()=>{
            props.history.push('/about');
    },5000)

    const {value, setValue } = useContext(UserContext);
    return(
        <React.Fragment>
            <h1>Hello I am home component</h1>

            <p>{value}</p>
        </React.Fragment>
    )
}

export default Home;