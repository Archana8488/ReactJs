import React, { useContext, useEffect, useState, useReducer } from 'react';
import { UserContext } from '../components/context/UserContext';
import { Table, Card, CardBody } from 'reactstrap';
import { Row, Col } from 'react-bootstrap';
import { reducer, iState } from '../App';

const About = () => {
    const { value, setValue } = useContext(UserContext);

    const [toHistory, setToHistory] = useState([]);

    useEffect(() => {
        debugger;
        fetch(`https://jsonplaceholder.typicode.com/posts/1/comments`)
            .then(res => res.json())
            .then(res2 => {
                setToHistory(res2);
            })
            .catch(error => console.log(error));
    }, []);

    const [data, dispatch] = useReducer(reducer, iState);

    // const changeName = () => {
    //     dispatch({ type: "CHANGE_NAME", payload: "Change name" },
    //         { type: "CHANGE_DES", payload: "Change DES" }
    //     )
    // }
    
    return (
        <React.Fragment>
            <h1>Hello I am about component</h1>
            <Row>
                <Col xs="4">
                    <p>{value}</p>
                    <button onClick={() => setValue("change context value")}>Change Value</button>
                </Col>
                <Col xs="4">
                    <h2>my name is : {data.name}</h2>
                    <h2>and my designation is : {data.designation}</h2>
                    <button onClick={() => dispatch({ type: "CHANGE_NAME", payload: "Reducer" })}>Change Name</button>
                </Col>
            </Row>
            <br />
            <Row>
                <Card>
                    <CardBody>
                        <Table>
                            <thead>
                                <tr>
                                    <th>User Id</th>
                                    <th>Title</th>
                                    <th>Body</th>
                                </tr>
                            </thead>
                            <tbody>
                                {toHistory.length > 0 ? (
                                    toHistory.map(todo => (
                                        <tr key={todo.id}>
                                            <td>{todo.id}</td>
                                            <td>{todo.title}</td>
                                            <td>{todo.body}</td>
                                        </tr>
                                    ))
                                ) : (
                                        <tr>
                                            <td colSpan={3}>No users</td>
                                        </tr>
                                    )}
                            </tbody>
                        </Table>
                    </CardBody>
                </Card>
            </Row>
        </React.Fragment>
    )
}

export default About;