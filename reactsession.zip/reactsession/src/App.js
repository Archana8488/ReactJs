import React, { useState, useReducer } from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import ToolBar from './navbar/Navbar';
import Home from './home/Home';
import About from './home/About';
import User from './components/user/User';
import { UserContext } from './components/context/UserContext';

export const iState =
  { name: "Archana Singh", designation: "S/W" }


export const reducer = (state, action) => {
  switch (action.type) {
    case 'CHANGE_NAME':
      return {
        ...state,
        name: action.payload
      }
    default:
      return state

  }

}

function App() {

  const [value, setValue] = useState("Hello i am context value");

  return (
    <BrowserRouter>
      <div className="container">
        <h3 className="m-3 d-flex justify-contnet-center">
          React App With Context
      </h3>
        <ToolBar />
        <Switch>
          <UserContext.Provider value={{ value, setValue }}>
            <Route path='/' exact component={Home} />
            <Route path='/user' exact component={User} />
            <Route path='/about' exact component={About} />
          </UserContext.Provider>
        </Switch>

      </div>
    </BrowserRouter>
  );
}

export default App;
